# ADN Ideas 2027

Página sencilla para recibir ideas de comunicaciones de ADN, con identidad visual basada en el fondo y el logo proporcionados.

## Archivos
- `index.html`: formulario público de una sola pregunta.
- `repositorio.html`: vista de las ideas y exportación CSV.
- `assets/fondo-adn.png`: fondo gráfico.
- `assets/logo-adn.png`: logo ADN.

## Probar localmente
Abre `index.html` en un navegador. Para revisar el repositorio, abre `repositorio.html` en el mismo navegador.

## Importante sobre el almacenamiento
Esta versión de demostración guarda las propuestas en `localStorage` del navegador. Eso significa que las ideas solo quedan disponibles en el mismo navegador/dispositivo donde se enviaron. **No es todavía una base de datos compartida ni sirve como repositorio central para todos los adolescentes.**

Para publicarlo como sitio real con repositorio central, hay que desplegar estos archivos en un servicio de hosting y conectar el formulario a una base de datos compartida (por ejemplo, Supabase, Firebase, Google Sheets mediante una integración segura o un backend institucional). No se incluyen credenciales ni servicios externos en este repositorio.
